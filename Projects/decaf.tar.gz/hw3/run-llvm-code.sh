b=`basename $1 .ll`
llvm-as-2.9 $1
llc-2.9 $b.bc
gcc $b.s decaf-stdlib.c -o $b
./$b
rm -f $1.bc $b.s $b
