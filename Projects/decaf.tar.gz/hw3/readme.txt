

note that marker-nojoy.y will not be acceptable to bison. for the
reason, first check what marker-nojoy.y is trying to do, and then
check the correct syntax for bison in expr-inherit.y

expr-grammar.y contains the grammar for the code generation question
in this homework. The files expr-testfile-*.txt contain the test
programs that should compile and produce valid code in your
implementation.

decaf-stdlib.c is the decaf standard library containing the print_int,
print_string, and read_int functions that can be used in Decaf
programs. In the full Decaf compiler we will enforce that such
external functions must be defined in the extern definition list.

Anoop Sarkar
<anoop@cs.sfu.ca>

