Q3: initial coding done individually - code had bugs, which were resolved by Simranjit 
    testing with Simranjit

Q9: coding done as a group
    testing and code review


