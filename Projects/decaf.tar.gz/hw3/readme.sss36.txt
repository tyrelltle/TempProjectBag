Q3: the development for the symbol table logic with team 
    worked with priyam to test the question

Q9: the development for the question with team
    resolved some diff, logic for the load and bool to int32
    testing and code review

Misc: team meatings, final compilation of the submittion

