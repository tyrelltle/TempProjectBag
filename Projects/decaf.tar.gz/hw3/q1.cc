#include <iostream>
#include <map>
#include <list>

using namespace std;

typedef unsigned int int_32;

enum type_e
{
   int_e,
   char_e,
   string_e,
};

struct descriptor
{
   type_e type;
   int_32 reg_dest;
   int_32 mem_add;
   int spilled;     // 0 reg_dest, 1 mem_add
   int int_val;
};

typedef map<string, descriptor*> symbol_table;
typedef list<symbol_table> symbol_table_list;
symbol_table_list symtbl;

descriptor* access_symtbl(string ident)
{
   for(symbol_table_list::iterator i = symtbl.begin();
         i != symtbl.end(); ++i )
   {
      symbol_table::iterator find_ident;
      if((find_ident = i->find(ident)) != i->end())
         return find_ident->second;
   }
   return NULL;   
}

descriptor* fillinfo( type_e type, int_32 location, int spilled )
{
   descriptor* desc = new descriptor;
   desc->type = type;
   if( desc->spilled == 0 )
      desc->reg_dest = location;
   else
      desc->mem_add = location;
   return desc;
}

int main()
{
   symbol_table* sym1 = new symbol_table;
   string str1 = "aa";
   descriptor* desc1;
   desc1 = fillinfo( int_e, 0, 0 );
   desc1->int_val = 10;
   sym1->insert(pair<string, descriptor*>(str1, desc1));
   symtbl.push_back( *sym1 );
   
   symbol_table* sym2 = new symbol_table;
   string str2 = "bb";
   descriptor* desc2;
   desc2 = fillinfo( int_e, 0, 0 );
   desc2->int_val = 20;
   sym2->insert(pair<string, descriptor*>(str2, desc2));
   symtbl.push_back( *sym2 );

   symbol_table* sym3 = new symbol_table;
   string str3 = "cc";
   descriptor* desc3;
   desc3 = fillinfo( int_e, 0, 0 );
   desc3->int_val = 30;
   sym3->insert(pair<string, descriptor*>(str3, desc3));
   
   str3 = "dd";
   descriptor* desc4;
   desc4 = fillinfo( int_e, 0, 0 );
   desc4->int_val = 40;
   sym3->insert(pair<string, descriptor*>(str3, desc4));
   symtbl.push_back( *sym3 );   
   
   descriptor* desc5;
   desc5 = access_symtbl(str1);
   cout<<desc5->int_val<<endl;
   desc5 = access_symtbl(str2);
   cout<<desc5->int_val<<endl;
   desc5 = access_symtbl(str3);
   cout<<desc5->int_val<<endl;

   
   
   

   
   return 0;
}

