#include <algorithm>
#include <iostream>
#include <fstream>
#include <iostream>
#include <sstream>
#include <utility>
#include <map>
#include <list>
#include <iterator>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include <stdio.h>
#include <algorithm>
#include <string>


#include <cstring>
using namespace std;





typedef  struct desc{
  

int valore;
  int riga;
  string *stampami;
  string *tipo;
  int regAddress ;
 }descriptor;

typedef  struct ident{
  
char *id;
  char *stampala;
int valore;
  int riga;
  string *tipo;
 }identificatrice;


   typedef descriptor* bastardo;
  
typedef bastardo punt;





typedef map <string, bastardo> symbol_table ;


typedef symbol_table *tabella;


typedef list<symbol_table > symbol_table_list;

typedef list<symbol_table >::iterator list_iter;


typedef symbol_table_list *listone;

typedef map <string, bastardo>::iterator dict_iter;

typedef list <int> catena; //1st string
typedef map <string,catena> vediamo; 

