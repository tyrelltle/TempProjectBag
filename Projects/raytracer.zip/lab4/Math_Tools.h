/*
Includes all classes of linear algebra primatives like point, vertex and line
also include classes containing vector operations 
*/

#ifndef MATH_TOOLS_H
#define MATH_TOOLS_H

#include<math.h>
#include <stdlib.h>
#include<vector>
using namespace std;

class Color
{
public:	
	Color();
	Color(const Color&);
	Color(float r_, float g_, float b_);
	void change_if_need();//set color value compoents to 1 if >1 or 0 if <0 
	void addition(Color *c);
	void addition(float f);
	void scale(Color *c);
	void scale(float scale);
	void scale(float r_, float g_, float b_); 
	void takeCeiling();
	void copy(Color *c);
	void copy(float r_, float g_, float b_);
	float r,g,b;
};

class Point
{
public:
	Point();
	Point(float X, float Y, float Z);
	void copy(float X, float Y, float Z);
	void scale(float s);
	float distance(Point *p);
	float distance(float x_, float y_, float z_);
	bool equals(Point *);
	float x,y,z;	
};



class Vector:public Point
{
public:
	Vector();
	Vector(float x, float y, float z);
	Vector(Point *a, Point*b);
	Vector(float x, float y, float z, float u, float v, float w);//get vector from (u,v,w)-(x,y,z)
	void substract(Vector *v);
	void normalize();
	void copy(float x, float y, float z);
	void copy(Vector *);

	void scale(float s);
	float dot(Vector *);
	Vector* cross(Vector *);
	
};



class Line
{
public:
	Line();

	~Line();
	void define_equation(Point *p0, Vector *direction);
	void define_equation(Point *p1, Point *p2);
	void getPoint(float t, Point *p);//get point on line, given t in line equation p=p0+Vt
	Point* getPoint(float t);

	float length;
	Vector* unitVector;
//private:
	float equation_X0;
	float equation_Y0;
	float equation_Z0;
	float equation_Vx;
	float equation_Vy;
	float equation_Vz;
	/*above variables form line
	  x=X0+Vx*t
	  y=Y0+Vy*t
	  z=Z0+Vz*t	
	*/

};


class Face
{
public:
	Face(Point *p1, Point *p2, Point *p3 );
	Face(Point *p1, Point *p2, Point *p3, Point *vt1, Point *vt2, Point *vt3);
	~Face();
	int max_coordinate();
	void defineEquation();
	float a,b,c,d;
	Point *p1,*p2,*p3;

	Point *vt1, *vt2, *vt3;
	Vector *normal;

};






class Pixel
{
public:
	Pixel();
	Pixel(Point*);
	Color *color;
	Point *point;

};



class TransformationMatrix
{ //Transformation matrix that orients coordinats in original coordinate system
  //to u-v-n system
public:
	TransformationMatrix(Vector * origin_up, Point *origin_cam_loc, Point *origin_target, float angle, int screenWidth, int screenHeight);
	~TransformationMatrix();	
	void Transform(float &x, float &y, float &z);
	void Transform(Point *p);
	
	Point *VRP; //view reference point
	float get_distance_VRP_COP();
	void get_plane_size(float &width, float &height);
//private:
	Vector *v;
	Vector *n;
	Vector *u;

	
	float viewPlane_width, viewPlane_height;
	float distance_VRP_COP;
};



#endif
