#include"Object.h"

using namespace std;

Light::Light(Color *c, Point *p)
{
	color=c;
	point=p;
}

Light::~Light()
{
	delete(color);
	delete(point);
}

Material::Material()
{}
Material::Material(float r_, float g_, float b_, 
		  float Ka_, float Kd_, float Ks_,
		  float n_s_, float T_, float index_of_refraction_)
{
	r=r_;
	g=g_;
	b=b_;
	Ka=Ka_;
	Kd=Kd_;
	Ks=Ks_;
	n_s=n_s_;
	T=T_;
	index_of_refraction=index_of_refraction_;
}

Material::Material(Material *m)
{
	r=m->r;
	g=m->g;
	b=m->b;
	Ka=m->Ka;
	Kd=m->Kd;
	Ks=m->Ks;
	n_s=m->n_s;
	T=m->T;
	index_of_refraction=m->index_of_refraction;
}






