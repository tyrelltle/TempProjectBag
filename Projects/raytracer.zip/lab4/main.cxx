/*
decomstructor delete all vector's all objects

mesh normal
*/






#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <iomanip>
#include <iostream>
#include "Math_Tools.h"
#include "Object.h"
#include "Screen.h"


//I made view reference point the origin not Centre of projection
//because there is no great difference. 
#define VRP_X	0
#define VRP_Y	0
#define	VRP_Z	0


#define MAX_RAY_LENGTH 100

using namespace std;

void decomstructor();

void TransformObjects();

void printImage();

void ReadData(const char* fname);

Color *Shade(Object *o, Color *materialcolor, Line *ray, Point* intercect, Vector *normal, int depth);

Color *Trace_ray(Line *ray, int depth);
Color *Trace_ray_(Object*start, Line *ray, int depth);
void Trace();


//Global Variables
Material* 		current_material;
string			current_texture="none";
Point 			camera_from;
Point 			camera_target;
Vector 			camera_up;
float 			camera_angle;
int 			width,height;//pixel resolution.  just for convinience I call them width and height
float			plane_width, plane_height;//projection plane size
Color 			background;
Color 			ambient_light;
int 			trace_depth;
Point *COP;
Screen *		screen;
vector<Object *> 	objects;
vector<Light *>		lights;
string outfilename;


TransformationMatrix* 	trans_matrix;

void decomstructor()
{
	delete(current_material);
	delete(COP);
	for(int i=0;i<objects.size();i++)
		delete(objects[i]);

	for(int i=0;i<lights.size();i++)
		delete(lights[i]);
	delete(trans_matrix);

	delete(screen);

}
void TransformObjects()
{
	trans_matrix=new TransformationMatrix(&camera_up, &camera_from, &camera_target,  camera_angle, width, height);
	for(int i=0;i<objects.size();i++)
	{
			objects[i]->transform(trans_matrix);
	}	

	for(int j=0;j<lights.size();j++)
		trans_matrix->Transform(lights[j]->point);

}



void printImage()
{	Pixel *temp;
	ofstream outf(outfilename.c_str(), ios::out);

	outf<<"P3"<<endl;
	outf<<width<<" "<<height<<endl;
	outf<<"255"<<endl;


	for(int i=0;i<height;i++)
	{	
		for(int j=0;j<width;j++)
		{

			temp=screen->getPixel(i,j);
			outf<<"\t"<<temp->color->r<<" "<<temp->color->g<<" "<<temp->color->b<<"\t";
		}
		outf<<endl;
	}

	outf.close();
	
	


}
void ReadData(const char* fname)
{	
	cout<<"Reading input file and initializing"<<endl;



	float tempf1,tempf2;
	current_material=new Material();
	string char_para;//string parameter
	Object *temp_object;
	ifstream *f=new ifstream(fname, ios::in);
	if(!*f){
		cout<<"error reading file"<<endl;
			
	}

	while((*f)>>char_para&&!f->eof())
	{	
		if(char_para=="material")
		{
			(*f)>>current_material->r>>current_material->g>>current_material->b>>
			      current_material->Ka>>current_material->Kd>>current_material->Ks>>
			    current_material->n_s>>current_material->T>>current_material->index_of_refraction;

		}
   		else if(char_para=="sphere")
		{


			temp_object=new Sphere(new Material(current_material));
			(*f)>>static_cast<Sphere *>(temp_object)->x>>
			      static_cast<Sphere *>(temp_object)->y>>
			      static_cast<Sphere *>(temp_object)->z>>
			      static_cast<Sphere *>(temp_object)->radius;
			if(current_texture!="none")
			   			{
			   				temp_object->setTexture(current_texture);
			   			}
			objects.push_back(temp_object);
			temp_object=NULL;
		}
   		else if(char_para=="mesh")
   		{
   			string objName;
   			temp_object=new Mesh(new Material(current_material));
   			(*f)>>objName;

   			static_cast<Mesh *>(temp_object)->fetchData(objName);
   			if(current_texture!="none")
   			{
   				temp_object->setTexture(current_texture);
   			}
   			objects.push_back(temp_object);
   			temp_object=NULL;

   		}
		else if(char_para=="camera_from")
		{
			(*f)>>camera_from.x>>camera_from.y>>camera_from.z;
		}
		else if(char_para=="camera_target")
		{
			(*f)>>camera_target.x>>camera_target.y>>camera_target.z;
		}
		else if(char_para=="camera_up")
		{
			(*f)>>camera_up.x>>camera_up.y>>camera_up.z;
		}
		else if(char_para=="camera_angle")
		{
			(*f)>>camera_angle;
			
		}
		else if(char_para=="camera_resolution")
		{
			(*f)>>width>>height;
		
		}
		else if(char_para=="background")
		{
			(*f)>>background.r>>background.g>>background.b;
		}
		else if(char_para=="ambient_light")
		{
			(*f)>>ambient_light.r>>ambient_light.g>>ambient_light.b;
		}
		else if(char_para=="point_light")
		{
			Point *p=new Point();
			Color *c=new Color();
			(*f)>>c->r>>c->g>>c->b>>p->x>>p->y>>p->z;
			lights.push_back(new Light(c,p));


		}
		else if(char_para=="texture")
		{
			(*f)>>current_texture;
		}
		else if(char_para=="trace_depth")
		{
			(*f)>>trace_depth;
			
		}
		else if(char_para=="render")
		{
			(*f)>>outfilename;

		}


	}
	
	TransformObjects();

	f->close();
	delete(f);
	


	trans_matrix->get_plane_size(tempf1,tempf2);
	screen=new Screen(tempf1,tempf2,width,height);
	plane_width=30;
	plane_height=20;


}



//All functions below are main functions that dose the ray tracing
//----------------------------------------------------------------

Color *Shade(Object *o, Color *materialcolor, Line *ray, Point* intercect, Vector *normal, int depth)
{

	Color* returnC=new Color(ambient_light);
	Point *p0=ray->getPoint(0);
	//ambient_light term
	returnC->scale(o->getMaterial()->Ka);
	returnC->scale(materialcolor);
	Line *rayToLight=new Line();//line from current intercect on object to light source
	Color *lightC=new Color();
	Color *materialLight=new Color();
	Color *reflectC=NULL;
	Color *refractC=NULL;
	Point *tempP=new Point();
	Vector *viewPoint=new Vector(intercect->x,intercect->y,intercect->z,COP->x,COP->y,COP->z);
	Point *light_self_intercect;
	Point *light_object_intercect;
	viewPoint->normalize();
	float temp;
	float cosPow;
	Vector *reflect=new Vector();

	Line *ray_reflection=new Line();
	Line *ray_refraction=new Line();



	float lightdot;
	float att;
	for(int i=0;i<lights.size();i++)
	{
		rayToLight->define_equation(intercect,lights[i]->point);
		//copy light's color to lightC, lightC is a temp variable
		lightC->copy(lights[i]->color);
		//compute how much light is blocked from any object


		for(int j=0;j<objects.size();j++)
		{
		if(objects[j]!=o){
			light_object_intercect=objects[j]->hit(rayToLight,intercect, NULL, false,NULL);
			if(light_object_intercect!=NULL) //light_object_intercect->eqluals(light_self_intercect))
			{
				temp=light_object_intercect->distance(lights[i]->point);
				if(temp<intercect->distance(lights[i]->point))
					lightC->scale(objects[j]->getMaterial()->T);

			}//end if
			delete(light_object_intercect);
			light_object_intercect=NULL;}
		}//end for




		//scale diffuse term and spectancular term
		lightdot=rayToLight->unitVector->dot(normal);
			//rayToLight->unitVector->scale(-1);
		//copy material light for calculation
		materialLight->copy(materialcolor);
		if(lightdot<0){
			lightdot=0;
		}
		materialLight->scale((o->getMaterial()->Kd*lightdot));


		//--------------compute (R*V)^n
		reflect->copy(normal->x,normal->y,normal->z);
		reflect->scale(2*(normal->dot(rayToLight->unitVector)));
		reflect->substract(rayToLight->unitVector);



		//-----------------------------

		cosPow=reflect->dot(viewPoint);
		if(cosPow<0)
			cosPow=0;
		cosPow=pow(cosPow,o->getMaterial()->n_s);

		materialLight->addition(cosPow*o->getMaterial()->Ks);


		materialLight->scale(lightC);

		//scale att
		att=1.0/(rayToLight->length*rayToLight->length);

		materialLight->scale(att);

		returnC->addition(materialLight);


		light_self_intercect=NULL;
	}



	if(depth<trace_depth)
	{	//begin to calculate reflection

		if(o->getMaterial()->Ks>0)
		{//reflectable

			float c1=-normal->dot(ray->unitVector);
			reflect->copy(ray->unitVector->x+(2*normal->x*c1),
						ray->unitVector->y+(2*normal->y*c1),
						ray->unitVector->z+(2*normal->z*c1));
			reflect->normalize();

			ray_reflection->define_equation(intercect, reflect);
			reflectC=Trace_ray_(o,ray_reflection,depth+1);
			reflectC->scale(o->getMaterial()->Ks);
			//cout<<reflectC->r<<reflectC->g<<reflectC->b<<endl;
			returnC->addition(reflectC);



		}

		//begin to calculate refraction

		//calculate refraction ray

			Vector *n=new Vector();
			Vector *I=new Vector();
			n->copy(normal);
			I->copy(rayToLight->unitVector);
			float kt=o->getMaterial()->index_of_refraction;
		if(1-kt*kt*(1-normal->dot(I)*normal->dot(I))>=0)
		{

			float scalen=kt*normal->dot(I)-
						 sqrt(1-kt*kt*(1-normal->dot(I)*normal->dot(I)));
			n->scale(scalen);
			I->scale(kt);
			Vector *vt=new Vector(I,n);
			vt->normalize();


			ray_refraction->define_equation(intercect, vt);
			delete(vt);

			refractC=Trace_ray(ray_refraction,depth+1);
			refractC->scale(o->getMaterial()->T);
			returnC->addition(refractC);
		}
			delete(n);
			delete(I);



	}//end if





	delete(ray_reflection);
	delete(ray_refraction);
	delete(reflect);
	delete(lightC);
	delete(rayToLight);
	delete(tempP);
	delete(materialLight);
	delete(p0);
	//if(reflectC!=NULL)
	//	delete(reflectC);
	return returnC;

}


Color *Trace_ray(Line *ray, int depth)
{
	return Trace_ray_(NULL, ray,depth);
}

Color *Trace_ray_(Object *start, Line *ray, int depth)
{
	Color *returnC;
	//find intercect with object
	bool hit=false;
	int hitObject=-1;
	Point *intercect=NULL;
	Color *color=new Color();
    Color *colorweneed=new Color();
	Point *linePoint;
	float min_dist=1000;
	float dist;
	Vector *normal=new Vector();
	Vector *intercectNormal=new Vector();
	Point *p0=ray->getPoint(0);

	for(int i=0;i<objects.size();i++)
		{
			linePoint=objects[i]->hit(ray,p0,normal,true,color);
			if(linePoint!=NULL)
			{
					dist=p0->distance(linePoint);


					if(dist>0 && dist<min_dist&&!linePoint->equals(p0)&&objects[i]!=start)
					{ hit=true;
					  min_dist=dist;
					  hitObject=i;
					  colorweneed->copy(color);
					  intercectNormal->copy(normal);
					  intercect=linePoint;

					}
					else
					{

						delete(linePoint);
						linePoint=NULL;
					}

					//break;
			}//end if

		}//end for

	delete(p0);
	if(hit)
	{	//cout<<objects[hitObject]->signiture()<<endl;
		//get normal to the intercect
		returnC=Shade(objects[hitObject], colorweneed, ray, intercect, intercectNormal,depth);
		delete(colorweneed);
		delete(intercect);
		delete(color);
		delete(normal);
		delete(intercectNormal);
		return returnC;
	}
	else
	{
		delete(colorweneed);
		delete(color);
		returnC=new Color(background.r,background.g,background.b);
		return returnC;
	}
}

void Trace()
{
	Pixel *temp;
	Line *ray=new Line();
	float COP_z=trans_matrix->get_distance_VRP_COP();//get z value of center of projection

	COP=new Point(0,0,COP_z);
	

	for(int i=0;i<height;i++)
	{	
		for(int j=0;j<width;j++)
		{//this inner loop actually is like a scan line
			temp=screen->getPixel(i,j);;
			ray->define_equation(COP,temp->point);
			temp->color=Trace_ray(ray, 1);
			temp->color->change_if_need();
			temp->color->scale(255.0);
			temp->color->takeCeiling();
			
		}
		
	}	

	delete(ray);
	


}







int main()
{

	string fn;
	cout<<"please enter name of your input file: ";
	cin>>fn;
	cout<<endl<<endl<<"--program starts"<<endl;
	cout<<"--reading file"<<endl;
	ReadData(fn.c_str());
	cout<<"--performing ray tracing"<<endl;
	Trace();
	cout<<"--rendering final image"<<endl;
	printImage();
	decomstructor();
	cout<<"--image successfully rendered\n to see the output image, please open "<<outfilename;

}








