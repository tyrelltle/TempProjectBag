#include "Math_Tools.h"
#include <iostream>
Color::Color()
{
	r=g=b=1;

}

Color::Color(const Color &c)
{
	this->copy(c.r,c.g,c.b);

}


Color::Color(float r_, float g_, float b_)
{
	r=r_;
	g=g_;
	b=b_;
}

void Color::takeCeiling()
{
	r=ceil(r);
	g=ceil(g);
	b=ceil(b);
}
void Color::addition(Color *c)
{
	r=c->r+r;
	g=c->g+g;
	b=c->b+b;
}

void Color::addition(float f)
{
	r=r+f;
	g=g+f;
	b=b+f;
}

void Color::scale(Color *c)
{
	r=r*c->r;
	g=g*c->g;
	b=b*c->b;
}

void Color::scale(float scale)
{
	r=r*scale;
	g=g*scale;
	b=b*scale;
}

void Color::scale(float r_, float g_, float b_)
{
	r*=r_;
	g*=g_;
	b*=b_;
}

void Color::copy(Color *c)
{

	r=c->r;
	g=c->g;
	b=c->b;	
}
void Color::copy(float r_, float g_, float b_)
{
	r=r_;
	g=g_;
	b=b_;
}
void Color::change_if_need()
{
	if(r>1)
		r=1;
	else if(r<0)
		r=0;


	if(g>1)
		g=1;
	else if(g<0)
		g=0;

	if(b>1)
		b=1;
	else if(b<0)
		b=0;

}
Point::Point()
{

}

Point::Point(float X, float Y, float Z)
{
	x=X;
	y=Y;
	z=Z;
}
void Point::copy(float X, float Y, float Z)
{
		x=X;
		y=Y;
		z=Z;

}


float Point::distance(float x_, float y_, float z_)
{
	return sqrt((x_-x)*(x_-x)+(y_-y)*(y_-y)+(z_-z)*(z_-z));
}
float Point::distance(Point *p)
{
	return distance(p->x, p->y, p->z);
}

void Point::scale(float s)
{
	x*=s;
	y*=s;
	z*=s;
}

bool Point::equals(Point *p)
{	if(p==NULL)
		return false;
	return p->x==x && p->y==y && p->z==z;
}

Vector::Vector()
{}

Vector::Vector(float x, float y, float z):Point(x,y,z)
{
}

Vector::Vector(float x, float y, float z, float u, float v, float w):Point(u-x,v-y,w-z)
//get vector from (u,v,w)-(x,y,z)
{


}

void Vector::copy(float x, float y, float z)
{
	this->x=x;
	this->y=y;
	this->z=z;
}

Vector::Vector(Point *a, Point *b):Point(b->x-a->x,b->y-a->y, b->z-a->z)
{}

void Vector::scale(float s)
{
	x*=s;
	y*=s;
	z*=s;
}

void Vector::copy(Vector *v)
{
	x=v->x;
	y=v->y;
	z=v->z;
}

void Vector::substract(Vector *v)
{
	x=x-v->x;
	y=y-v->y;
	z=z-v->z;
}
void Vector::normalize()
{
	float norm=sqrt(x*x+y*y+z*z);
	x=x/norm;
	y=y/norm;
	z=z/norm;
	
}

float Vector::dot(Vector *b)
{
	return x*b->x+y*b->y+z*b->z;
}

Vector*Vector::cross(Vector *b)
{
/*
vx = v1y * v2z - v1z * v2y
		
vy = v1z * v2x - v1x * v2z
		
vz = v1x * v2y - v1y * v2x
*/


	Vector* newv=new Vector();
	newv->x=y*b->z-z*b->y;
	newv->y=z*b->x-x*b->z;
	newv->z=x*b->y-y*b->x;

	return newv;
}


Line::Line(){unitVector=NULL;}




Line::~Line()
{
	if(unitVector!=NULL)
	delete(unitVector);
}

void Line::define_equation(Point *p1, Point *p2)
{/*defines equation of the line given 2 points through this line

 here, normalize the direction vector of p2-p1 because 
 it will be convinent later. Because, forexample: line equation
 of x part is , p=p0+V*t where V is direction vector
 if I set t=1, the new point p generated from the equation has distance
 from initial point !=1. But if I normalize the direction vector V before
 construct the equation p=p0+V*t,  then as I intrease t, I get new point 
 with unit distance from previous point 
*/	
	length=sqrt((p2->x-p1->x)*(p2->x-p1->x)+(p2->y-p1->y)*(p2->y-p1->y)+(p2->z-p1->z)*(p2->z-p1->z));
	Vector* directVector=new Vector(p2->x-p1->x, p2->y-p1->y, p2->z-p1->z);
	
	directVector->normalize();
	if(unitVector!=NULL)
		delete(unitVector);
	unitVector=directVector;
	equation_X0=p1->x;
	equation_Y0=p1->y;
	equation_Z0=p1->z;

	equation_Vx=directVector->x;
	equation_Vy=directVector->y;
	equation_Vz=directVector->z;

	
}

void Line::define_equation(Point *p0, Vector *direction)
{
	direction->normalize();
	equation_X0=p0->x;
	equation_Y0=p0->y;
	equation_Z0=p0->z;

	equation_Vx=direction->x;
	equation_Vy=direction->y;
	equation_Vz=direction->z;

	if(unitVector!=NULL)
		delete(unitVector);
	this->unitVector=new Vector(direction->x, direction->y, direction->z);
	//this->unitVector->normalize();
}
void Line::getPoint(float t, Point *p)
{//get point on line, given t in line equation p=p0+Vt
	p->x=equation_X0+equation_Vx*t;
	p->y=equation_Y0+equation_Vy*t;
	p->z=equation_Z0+equation_Vz*t;
}
Point* Line::getPoint(float t)
{
	Point*p=new Point();
	getPoint(t,p);
	return p;
}

Pixel::Pixel()
{color=NULL;
 point=NULL;}

Pixel::Pixel(Point *p)
{
	point=p;
	color=NULL;
}

Face::Face(Point *p1, Point *p2, Point *p3)
{
	this->p1=p1;
	this->p2=p2;
	this->p3=p3;
	vt1=vt2=vt3=NULL;
}
Face::Face(Point *p1, Point *p2, Point *p3,Point *vt1, Point *vt2, Point *vt3)
{
	this->p1=p1;
	this->p2=p2;
	this->p3=p3;
	this->vt1=vt1;
	this->vt2=vt2;
	this->vt3=vt3;
}
void Face::defineEquation()
{
	Vector* p2_p1=new Vector(p2->x-p1->x, p2->y-p1->y, p2->z-p1->z);
	Vector* p3_p1=new Vector(p3->x-p1->x, p3->y-p1->y, p3->z-p1->z);

	normal=p2_p1->cross(p3_p1);
	normal->normalize();

	//calculate a,b,c,d in equation Ax+By+Cz+D=0
	a=normal->x;
	b=normal->y;
	c=normal->z;
	d=-a*p1->x-b*p1->y-c*p1->z;


	delete(p2_p1);
	delete(p3_p1);

}

int Face::max_coordinate()
{//determine max(A,B,C) in plane equation Ax+Bz+Cy+D=0
 //return =1 if A is max, 2 if B is max, 3 if C is max
	int ret=1;
	float max=a;

	if(max<b)
	{
		ret=2;
		max=b;
	}
	if(max<c)
	{
		ret=3;
		max=c;
	}

	return ret;


}

Face::~Face()
{delete(normal);}


TransformationMatrix::TransformationMatrix(Vector * origin_up, Point *origin_cam_loc, Point *origin_target,  float angle, int screenWidth, int screenHeight)
{
	float temp;
	Vector*tempv=new Vector();
	n=new Vector(-origin_target->x+origin_cam_loc->x,
		     -origin_target->y+origin_cam_loc->y,
		     -origin_target->z+origin_cam_loc->z);
	

	/*
	v=up-[ (up dot n)/(n dot n) ] *n
	*/
	
	temp=origin_up->dot(n)/n->dot(n);
	tempv->x=temp*n->x;
	tempv->y=temp*n->y;
	tempv->z=temp*n->z;

	v=new Vector(origin_up->x-tempv->x,
		     origin_up->y-tempv->y,
		     origin_up->z-tempv->z);
	
	
	

	// u=v cross n
	u=v->cross(n);



	u->normalize();
	v->normalize();
	n->normalize();

	


	VRP=new Point();
	//get distance from camera position to view reference point
	distance_VRP_COP=1;

	//add COP with view normal to get view reference point
	VRP->x=origin_cam_loc->x-(distance_VRP_COP*n->x);
	VRP->y=origin_cam_loc->y-(distance_VRP_COP*n->y);
	VRP->z=origin_cam_loc->z-(distance_VRP_COP*n->z);

	//cout<<origin_cam_loc->x<<" "<<origin_cam_loc->y<<" "<<origin_cam_loc->z<<endl;
	//cout<<VRP->x<<" "<<VRP->y<<" "<<VRP->z<<endl;
	
	
	//get view plane width and height
	float aspectRatio=(float)screenWidth/(float)screenHeight;

	if(screenWidth<=screenHeight){
		viewPlane_width=2*tan(angle/2)*distance_VRP_COP;
		viewPlane_height=viewPlane_width;
		viewPlane_width=aspectRatio*viewPlane_width;
	}
	else
	{
		viewPlane_width=2*tan(angle/2)*distance_VRP_COP;
		viewPlane_height=viewPlane_width/aspectRatio;
	}
	
	delete(tempv);
}

TransformationMatrix::~TransformationMatrix()
{
	delete(u);
	delete(v);
	delete(n);
	delete(VRP);
}
void TransformationMatrix::get_plane_size(float &width, float &height)
{
	width=viewPlane_width;
	height=viewPlane_height;
}
float TransformationMatrix::get_distance_VRP_COP()
{
	return distance_VRP_COP;
}

void TransformationMatrix::Transform(float &x, float &y, float &z)
{
	/*
	transformation matrix:

	Xu	Yu	Zu	-x*Xu-y*Yu-z*Zu
	
	Xv	Yv	Zv	-x*Xv-y*Yv-z*Zv

	Xn	Yn	Zn	-x*Xn-y*Yn-z*Zn

	where lower case x,y,z is coordiate of VRP
	*/


	
	
	x=u->x*x+u->y*y+u->z*z-VRP->x*u->x-VRP->y*u->y-VRP->z*u->z;
	y=v->x*x+v->y*y+v->z*z-VRP->x*v->x-VRP->y*v->y-VRP->z*v->z;
	z=n->x*x+n->y*y+n->z*z-VRP->x*n->x-VRP->y*n->y-VRP->z*n->z;

	
}
void TransformationMatrix::Transform(Point *p)
{
	Transform(p->x, p->y,p->z);
}




