----------Features implemented:

Output a valid ppm file.

Parse the camera parameters, set up the viewport and raycast spheres

Implement basic phong Illumination and shading.

Parse and raycast triangles (meshes read from obj files)

Shadows

Implement reflection (perfect specular) and refraction

Add basic texture mapping for "triangles"

----------Features not implemented:

Add basic texture mapping for "spheres"

pick 2 of the extra 10 mapping effects 


