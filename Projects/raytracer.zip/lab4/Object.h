#ifndef OBJECT_H
#define OBJECT_H
#include<string>
#include <fstream>
#include "Math_Tools.h"
#include<iostream>
#include<iomanip>
#include "PPMReader.h"
using namespace std;


class Light
{
public:
	Light(Color *c, Point *p);
	~Light();

	Color*color;	
	Point *point;
};






class Material
{
public:
	Material();
	Material(float r_, float g_, float b_, 
		 float Ka_, float Kd_, float Ks_,
		 float n_s_, float T_, float index_of_refraction_);

	Material(Material *);
	
	float r,g,b,Ka,Kd,Ks,n_s,T,index_of_refraction;
};


class Object
//empty base class. Just a convienence when 
//putting sphere and mesh obejct in one array
{
public:
	Object(Material *m)
	{
		material=m;
		textured=false;
	};

	virtual ~Object()
	{
		delete(material);
		if(textured)
			delete(texture);
	};

	Material *getMaterial()
	{	return material;
	};


	virtual bool roughhit(Point *p)
	{
			return false;
	};

	virtual void transform(TransformationMatrix *trans_matrix)
	{};
	virtual Point* hit(Line*ray, Point *COP, Vector *normal, bool wantNormal, Color *color)
	{return NULL;};
	
	virtual string signiture()
	{return "object";};

	void setTexture(string filename)
	{
			cout<<"loading texture file: "<<filename<<endl;
			texture=loadPPM(filename.c_str(), textured);

	}
	bool textured;
	image<rgb> *texture;

private:
	Material *material;

};






class Sphere:public Object
{
public:
	Sphere(Material *m, float X, float Y, float Z, float Radius):Object(m)
	{	x=X;
		y=Y;
		z=Z;
		radius=Radius;
	};
	~Sphere()
	{};

	Sphere(Material *m):Object(m){};


	Point* hit(Line*ray, Point *COP, Vector *normal, bool wantNormal, Color *color)
	{
//determine intercect with ray
		//mathematical ideal is from http://www.cs.unc.edu/~rademach/xroads-RT/RTarticle.html
		float r,c,v,disc;
		Vector *COP_CENTER=new Vector(COP->x, COP->y, COP->z,x,y,z);
		Point *intercect;
		c=COP->distance(x,y,z);
		v=COP_CENTER->dot(ray->unitVector);
		if(v<0)
			return NULL;
		r=radius;

		disc=r*r-(COP_CENTER->dot(COP_CENTER)-v*v);

		if(disc<0)
		{//no intercect
			delete(COP_CENTER);
			return NULL;
		}
		else
		{disc=sqrt(disc);
			intercect=new Point(COP->x+(v-disc)*ray->unitVector->x,
							 COP->y+(v-disc)*ray->unitVector->y,
							 COP->z+(v-disc)*ray->unitVector->z);
			if(wantNormal)
			{	normal->copy(x-intercect->x,
					  	  	  	  y-intercect->y,
					  	  	  	  z-intercect->z);
				normal->scale(-1);
				normal->normalize();
			}
			if(color!=NULL){
			if(textured)
			{
				/*int u=(int)(intercect->x/sqrt(pow(intercect->x, 2)+pow(intercect->y,2)+pow(intercect->z,2)));
				int v=(int)(intercect->y/sqrt(pow(intercect->x, 2)+pow(intercect->y,2)+pow(intercect->z,2)));
				int r,g,b;


				r=imRef(texture,u,v).r;
				g=imRef(texture, u,v).g;
				b=imRef(texture, u,v).b;
				color->copy(r,g,b);*/
				color->copy(this->getMaterial()->r,this->getMaterial()->g,this->getMaterial()->b);

			}
			else
			{
				color->copy(this->getMaterial()->r,this->getMaterial()->g,this->getMaterial()->b);

			}}


			delete(COP_CENTER);
			return intercect;

		}
	};
	
	void transform(TransformationMatrix *trans_matrix)
	{
		trans_matrix->Transform(x,y,z);

	};

	bool roughhit(Point *p)
	{
		return (ceil((p->x-x)*(p->x-x)+(p->y-y)*(p->y-y)+(p->z-z)*(p->z-z))==radius*radius);
	};

	 string signiture()
	{return "sphere";};


	float x,y,z,radius;
};


class Mesh:public Object
{
public:
	Mesh(Material *m):Object(m)
	{vertexs=new vector<Point *>();
	 faces=new vector<Face *>();
	 vt=new vector<Point *>();
	};

	~Mesh()
	{

		for(int i=0;i<vertexs->size();i++)
			delete((*vertexs)[i]);
		for(int j=0;j<faces->size();j++)
			delete((*faces)[j]);
		for(int x=0;x<vt->size();x++)
			delete((*vt)[x]);
		delete(vt);
		delete(faces);
		delete(vertexs);

	};

	string signiture()
	{return "mesh";};

	bool roughhit(Point *p)
	{

				return true;

	};
	void transform(TransformationMatrix *trans_matrix)
	{



		for(int i=0;i<vertexs->size();i++){
			trans_matrix->Transform((*vertexs)[i]);

		}
		for(int j=0;j<faces->size();j++)
		{
			(*faces)[j]->defineEquation();

		}


	};
	void fetchData(string objName)
	{
		ifstream *f=new ifstream(objName.c_str(), ios::in);
		Point *tempvertex;
		string slash="/";
		string facepara1, facepara2, facepara3;
		vector<string> *vec;
		string char_para;
		bool facepara_has_slash=true;
		//"face" command has formate:  face faceL1/faceR1   faceL2/faceR2   faceL3/faceR3
		int faceL1,faceL2,faceL3, faceR1,faceR2,faceR3;
		if(!*f)
		{
				cout<<"error reading file"<<endl;
		}

		while((*f)>>char_para&&!f->eof())
			{
				if(char_para=="f"){
					//cout<<"1";
					   (*f)>>facepara1>>facepara2>>facepara3;

					   if (std::string::npos != facepara1.find(slash))
					   {
					     vec=split(facepara1,'/');
					     faceL1=atoi((*vec)[0].c_str());
					     faceR1=atoi((*vec)[1].c_str());
					     delete(vec);
					     vec=NULL;

					   }
					   else
					   {
						   facepara_has_slash=false;
						  faceL1=atoi(facepara1.c_str());
					   }

					   if (std::string::npos !=  facepara2.find(slash))
					   {
					     vec=split(facepara2,'/');
					     faceL2=atoi((*vec)[0].c_str());
					     faceR2=atoi((*vec)[1].c_str());
					     delete(vec);
					     vec=NULL;
					   }
					   else
					   {
						   facepara_has_slash=false;
						   faceL2=atoi(facepara2.c_str());
					   }

					   if (std::string::npos !=  facepara3.find(slash))
					   {
					     vec=split(facepara3,'/');
					     faceL3=atoi((*vec)[0].c_str());
					     faceR3=atoi((*vec)[1].c_str());
					     delete(vec);
					     vec=NULL;
					   }
					   else
					   {
						  facepara_has_slash=false;
						  faceL3=atoi(facepara3.c_str());
					   }

					  if(!facepara_has_slash)
						  this->addFace(faceL1,faceL2,faceL3);
					  else
						  this->addFace(faceL1,faceL2,faceL3,faceR1, faceR2, faceR3);


				}
				else if(char_para=="v")
				{
					tempvertex=new Point();
					(*f)>>tempvertex->x>>tempvertex->y>>tempvertex->z;
					this->addVertex(tempvertex);
					tempvertex=NULL;

				}
				else if(char_para=="vt")
				{
					tempvertex=new Point();
					(*f)>>tempvertex->x>>tempvertex->y;
					this->vt->push_back(tempvertex);

					tempvertex=NULL;
				}
			}



		f->close();
		delete(f);

	};




	Point* hit(Line*ray, Point *COP, Vector *normal, bool wantNormal, Color *color){
		float denominator;
		float divisor;
		float min_dist=1000;
		long double t;
		float temp;
		float dist_y,dist_x, ratio_y,ratio_x;
		float x,y;//distance between face's
		Point *returnP=new Point();
		Point *rayPoint;

		bool hit=false;

		int withdrawaxis;
		int hitface;
		float U,V;
		for(int i=0;i<faces->size();i++)
		{
			denominator=(*faces)[i]->a*ray->equation_Vx+
						(*faces)[i]->b*ray->equation_Vy+
						(*faces)[i]->c*ray->equation_Vz;

				divisor=(-(*faces)[i]->a*COP->x
						 -(*faces)[i]->b*COP->y
						 -(*faces)[i]->c*COP->z
						 -(*faces)[i]->d);
				t=(divisor/denominator);

			if(denominator!=0&&t>=0)
			{
				//if(t<0)
				//	return NULL;
				//	return NULL;
				rayPoint=ray->getPoint(t);
				//cout<<rayPoint->x<<" "<<rayPoint->y<<" "<<rayPoint->z<<endl;
				//check if intercect is within triangle


				Point*p1_=new Point((*faces)[i]->p1->x, (*faces)[i]->p1->y,(*faces)[i]->p1->z);
				Point*p2_=new Point((*faces)[i]->p2->x, (*faces)[i]->p2->y,(*faces)[i]->p2->z);
				Point*p3_=new Point((*faces)[i]->p3->x, (*faces)[i]->p3->y,(*faces)[i]->p3->z);
				Point*rayPoint_=new Point(rayPoint->x,rayPoint->y,rayPoint->z);

				//we are droping one of the 3 coordinate(x,y,z).
				withdrawaxis=(*faces)[i]->max_coordinate();
				switch(withdrawaxis)
				{
				case 1:{//withdraw x
						p1_->x=0;
						p2_->x=0;
						p3_->x=0;
						rayPoint_->x=0;
						break;}
				case 2:{//withdraw y
						p1_->y=0;
						p2_->y=0;
						p3_->y=0;
						rayPoint_->y=0;
						break;}
				case 3:{//withdraw z
						p1_->z=0;
						p2_->z=0;
						p3_->z=0;
						rayPoint_->z=0;
						break;}
				}

				//begin: determine if point is in triangle
				Vector *v0=new Vector(p3_,p1_);
				Vector *v1=new Vector(p2_,p1_);
				Vector *v2=new Vector( rayPoint_,p1_);
				float dot00 = v0->dot(v0);
				float dot01 = v0->dot(v1);
				float dot02 = v0->dot(v2);
				float dot11 = v1->dot(v1);
				float dot12 = v1->dot(v2);

				// Compute barycentric coordinates
				float invDenom = 1.0 / (dot00 * dot11 - dot01 * dot01);
				float u = (dot11 * dot02 - dot01 * dot12) * invDenom;
				float v = (dot00 * dot12 - dot01 * dot02) * invDenom;

				// Check if point is in triangle
				if ((u>0) &&(v>0) && (u+v<1))
				{
					U=u;
					V=v;
					temp=COP->distance(rayPoint);
					if(temp<min_dist)
					{


							min_dist=temp;
							hit=true;
							hitface=i;
							returnP->copy(rayPoint->x,rayPoint->y,rayPoint->z);
					}

				}

				//end determining if point is in triangle
				delete(v0);
				delete(v1);
				delete(v2);
				delete(p1_);
				delete(p2_);
				delete(p3_);
				delete(rayPoint_);
			}//end if

		}//end for
			if(!hit)
			{
				if(returnP!=NULL)
				{	delete(returnP);
					return NULL;
				}
			}
			else
				{
					if(wantNormal)
						normal->copy((*faces)[hitface]->normal);
					if(color!=NULL)
					{

						if(this->textured&&(*faces)[hitface]->vt1!=NULL&&(*faces)[hitface]->vt2!=NULL&&(*faces)[hitface]->vt3!=NULL)
						{
							//get uv mapping

							float U_p1, U_p2, U_p3; //barycentric coordinates of p1 p2 p3
							float tri_area=triangle_area((*faces)[hitface]->p1,(*faces)[hitface]->p2,(*faces)[hitface]->p3);
							U_p1=triangle_area((*faces)[hitface]->p3, (*faces)[hitface]->p2,returnP) /tri_area;

							U_p2=triangle_area((*faces)[hitface]->p3, (*faces)[hitface]->p1,returnP) /tri_area;

							U_p3=triangle_area((*faces)[hitface]->p1, (*faces)[hitface]->p2,returnP) /tri_area;

							float tx=(U_p1 * (*faces)[hitface]->vt1->x  +
										 U_p2 * (*faces)[hitface]->vt2->x  +
										 U_p3 * (*faces)[hitface]->vt3->x);
							float ty=(U_p1 * (*faces)[hitface]->vt1->y  +
										 U_p2 * (*faces)[hitface]->vt2->y  +
										 U_p3 * (*faces)[hitface]->vt3->y);

							tx*=texture->width();
							ty*=texture->height();

							int txx=(int)tx;
							int tyy=(int)ty;
							//cout<<txx<<" "<<tyy<<endl;
							if(txx>=texture->width())
								txx=texture->width()-1;
							else if(txx<0)
								txx=0;
							if(tyy>=texture->height())
								tyy=texture->height()-1;
							else if(tyy<0)
								tyy=0;
							color->copy((1.0/255)*imRef(texture, txx, tyy).r,
										(1.0/255)*imRef(texture, txx, tyy).g,
									    (1.0/255)*imRef(texture, txx, tyy).b);
							delete(rayPoint);
							rayPoint=NULL;

						}
						else
						{

							color->copy(this->getMaterial()->r,this->getMaterial()->g,this->getMaterial()->b);
						}

					}



				}



			return returnP;

	};

	float triangle_area(Point *p1, Point *p2, Point *p3)
	{
		float b=p1->distance(p3);
		Vector*p1_p3=new Vector(p1,p3);
		Vector*p1_p2=new Vector(p1,p2);
		p1_p3->normalize();
		p1_p2->normalize();
		float tempL=p1_p3->dot(p1_p2) * p1->distance(p2);
		float d_p1_p2=p1->distance(p2);
		float h=sqrt(d_p1_p2*d_p1_p2-tempL*tempL);

		delete(p1_p3);
		delete(p1_p2);
		return b*h/2;

	};


	void addVertex(Point *p)
	{

		vertexs->push_back(p);
	};

	void addFace(int v1, int v2, int v3)
	{	Face *f;
		if(v1<=vertexs->size() && v2<=vertexs->size() && v3<=vertexs->size())
		{
			f=new Face((*vertexs)[v1-1],(*vertexs)[v2-1], (*vertexs)[v3-1]);
		}
		else
		{
			cout<<"face input is invalid:  not enough vertexs for the mesh"<<endl;
			return;
		}
		faces->push_back(f);
	};

	void addFace(int v1, int v2, int v3, int vt1, int vt2, int vt3)
	{	Face *f;

		if(v1<=vertexs->size() && v2<=vertexs->size() && v3<=vertexs->size()&&
		   vt1<=vertexs->size() && vt2<=vertexs->size() && vt3<=vertexs->size()
		)
		{
			f=new Face((*vertexs)[v1-1],(*vertexs)[v2-1], (*vertexs)[v3-1], (*vt)[vt1-1], (*vt)[vt2-1],(*vt)[vt3-1]);
		}
		else
		{
			cout<<"face input is invalid:  not enough vertexs for the mesh"<<endl;
			return;
		}
		faces->push_back(f);
	};

private:
	vector<Point *> *vertexs;
	vector<Face *> *faces;

	vector<string>* split(const string& strValue, char separator)
	{
	    vector<string> *vecstrResult=new vector<string>();
	    int startpos=0;
	    int endpos=0;

	    endpos = strValue.find_first_of(separator, startpos);
	    while (endpos != -1)
	    {
	        vecstrResult->push_back(strValue.substr(startpos, endpos-startpos)); // add to vector
	        startpos = endpos+1; //jump past sep
	        endpos = strValue.find_first_of(separator, startpos); // find next
	        if(endpos==-1)
	        {
	            //lastone, so no 2nd param required to go to end of string
	            vecstrResult->push_back(strValue.substr(startpos));
	        }
	    }

	    return vecstrResult;
	};

	vector<Point *> *vt;

};

#endif
