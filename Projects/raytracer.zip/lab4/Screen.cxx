#include "Screen.h"
#include<iostream>
Screen::Screen(float plane_width, float plane_height, int resolution_width, int resolution_height)
{	vector<Pixel *> *temp;
	plane_h=plane_height;
	plane_w=plane_width;
	float left_x,right_x,up_y,down_y;	
	
	left_x=-plane_w/2;//minimum x coordinate of pixel
	right_x=plane_w/2;//maximum x coordinate of pixel
	up_y=plane_h/2;//maximum y coordinate of pixel
	down_y=-plane_h/2;//minimum y coordinate of pixel

	x_step=(plane_width/2.0)/(resolution_width/2.0);
	y_step=(plane_height/2.0)/(resolution_height/2.0);


	pixelMap=new vector< vector<Pixel *>* >();
	
	resolu_w=resolution_width;
	resolu_h=resolution_height;

	for(int i=0;i<resolution_height;i++)
	{
			
		pixelMap->push_back(new vector<Pixel *>());
		for(int j=0;j<resolution_width;j++)
		{
			
			
			
				temp=(*pixelMap)[i];
				
				temp->push_back(new Pixel(new Point(left_x,up_y , -0.7)));
				//cout<<"("<<left_x<<", "<<up_y<<")   ";
				left_x+=x_step;
			
		}
		left_x=-plane_w/2;
		//cout<<endl;
		up_y-=y_step;
	}
}

Screen::~Screen()
{	vector<Pixel *> *temp;
	for(int i=0;i<resolu_h;i++)
		for(int j=0;j<resolu_w;j++)
	{
		temp=(*pixelMap)[i];		
		delete((*temp)[j]);

	}
	delete(pixelMap);

}

Pixel *Screen::getPixel(int y,int x)
{	
	vector<Pixel *> *temp;
	temp=(*pixelMap)[y];		
		
	return (*temp)[x];


}


