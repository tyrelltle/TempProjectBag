#ifndef PPMREADER_H
#define	PPMREADER_H
#include   <cstdlib>
#include   <climits>
#include   <cstring>
#include   <fstream>

#include   <iostream>

/*
 * FROM     http://topic.csdn.net/t/20050912/10/4263160.html

*/
using namespace std;

#define   BUF_SIZE   256

#define   imRef(im,   x,   y)   (im-> access[y][x])


#define   imPtr(im,   x,   y)   &(im-> access[y][x])
//http://topic.csdn.net/t/20050912/10/4263160.html

typedef struct
{
	unsigned char r,b,g;
}rgb;
template   <class   T>
class   image   {
  public:

    image(const   int   width,   const   int   height,   const   bool   init   =   true)
	 {
	    w   =   width;
	    h   =   height;
	    data   =   new   T[w   *   h];     //   allocate   space   for   image   data
	    access   =   new   T*[h];       //   allocate   space   for   row   pointers

	    //   initialize   row   pointers
	    for   (int   i   =   0;   i   <   h;   i++)
		access[i]   =   data   +   (i   *   w);

	    if   (init)
		memset(data,   0,   w   *   h   *   sizeof(T));
	};

    ~image() {
	    delete   []   data;
	    delete   []   access;
	};





    void   init(const   T   &val) {
	    T   *ptr   =   imPtr(this,   0,   0);
	    T   *end   =   imPtr(this,   w-1,   h-1);
	    while   (ptr   <=   end)
		*ptr++   =   val;
	};





    image <T>   *copy()   const{
	    image <T>   *im   =   new   image <T> (w,   h,   false);
	    memcpy(im-> data,   data,   w   *   h   *   sizeof(T));
	    return   im;
	};


    int   width()   const   {   return   w;   }


    int   height()   const   {   return   h;   }

    T   *data;


    T   **access;

  private:
    int   w,   h;
};








static   void   pnm_read(std::ifstream   &file,   char   *buf)   {
    char   doc[BUF_SIZE];
    char   c;

    file   >>   c;
    while   (c   ==   '#')   {
        file.getline(doc,   BUF_SIZE);
        file  >>   c;
    }
    file.putback(c);

    file.width(BUF_SIZE);
    file   >>   buf;
    file.ignore();
}

static   image <rgb>   *loadPPM(const   char   *name, bool &success)   {
    char   buf[BUF_SIZE],   doc[BUF_SIZE];


    std::ifstream   file(name,   std::ios::in   |   std::ios::binary);
    pnm_read(file,   buf);
    if   (strncmp(buf,   "P6 ",   2)){
        //throw   pnm_error();
        cout << "file "<<name<<" invalid or pnm   version   is  not  P6" <<endl;
        success=false;
        return NULL;
    }
    success=true;

    pnm_read(file,   buf);
    int   width   =   atoi(buf);
    pnm_read(file,   buf);
    int   height   =   atoi(buf);

    pnm_read(file,   buf);




    image <rgb>   *im   =   new   image <rgb> (width,   height, false);
   file.read((char *)imPtr(im,   0,   0),   width   *   height   *   sizeof(rgb));

    return   im;
}

static   void   savePPM(image <rgb>   *im,   const   char   *name)   {
    int   width   =   im-> width();
    int   height   =   im-> height();
    std::ofstream   file(name,   std::ios::out   |   std::ios::binary);

    file<< "P6\n " <<  width  << "   " <<  height <<  "\n " <<  UCHAR_MAX <<  "\n ";
    file.write((char   *)imPtr(im,   0,   0),   width   *   height   *   sizeof(rgb));
}


#endif
