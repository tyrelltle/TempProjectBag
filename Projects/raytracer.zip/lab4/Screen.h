#ifndef SCREEN_H
#define SCREEN_H
#include "Math_Tools.h"
#include <vector>
using namespace std;
/*
represents a screen containing every single element as a Pixel
a screen is simply a 2 dimentional vector of Pixel pointers

*/
class Screen
{
public:	
	Screen(float plane_width, float plane_height, int resolution_width, int resolution_height);
	~Screen();
	Pixel *getPixel(int y, int x);
private:
	float plane_h,plane_w;//together represents pixel location with respect to coordinate system
	float x_step, y_step; //because we are like puting a mask with holes on view plane, and the 
		              //number of holes = pixel_resolution_width x  pixel_resolution_height
			      //we need to know the distance between each hole. that are x_step and y_step
	int resolu_w, resolu_h;//resolution width and height
	//float viewPlane_width, viewPlane_height;
	vector< vector<Pixel *>* > *pixelMap;//the screen

};
#endif
