/*
The Server Entry
*/
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>

#include <time.h>
#include <string.h>
#include <vector>
#include <unistd.h>
#include <iostream>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <pthread.h>
#include "MessageContext.h"
#include "Server.h"
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <fstream>

#define MAX_BUFFER        2
#define MAX_BUFFER_TO_HOLD 1024
#define TIMEOUT			100
#define TIMEOUT_SEC			1000
#define MAX_IP_LEN	128
//#define SERVER_PORT        37453

using namespace std;



pthread_t listenerT;
pthread_t listenerSecT;
int serverFd;
Server server;

char * SERVER_IP;
int SERVER_PORT;
char PRI_IP[MAX_IP_LEN];
int PRI_PORT;

bool is_crash;
char* primarytxt;
typedef struct threadParameter
{
        int index;
        int clientSoket;
        pthread_t thread;

}PARA;

int numT; //number of thread
bool continue_;

bool mystrcmp(char *s1, const char *s2)
{
	int i=0;
	do{

		if(s1[i]!=s2[i])
			return false;



	}while(s1[i++]!='\0');
	return true;
}

void secondary(void *ptr)
{
		//cout<<"pass"<<endl;

                PARA* para=(PARA *)ptr;
                ptr=NULL;

                int clientSoket=para->clientSoket;
             
		long int len;
		
                char *mylog=readfile_sec(server.backup.c_str(), len);
		cout<<"sent log file to replica"<<endl<<endl;
		if(mylog==NULL)
			cout<<"failed to open backup file"<<endl;
		if(!mystrcmp(mylog,"&&&&&&&&&&"))
			strcat(mylog, "&&&&&&&&&&");
                if(send(clientSoket,(void *)mylog, strlen(mylog),MSG_NOSIGNAL)!=strlen(mylog))
		{
			cout<<"failed to send log from primary to secondary"<<endl;
			return ;		
		}
		//cout<<"sent to replica log file, with content:\n---------"<<endl;
		//cout<<mylog<<endl<<"---------"<<endl;
		if(mylog&&mylog!=NULL)
			free(mylog);
		getSem(SEM_SEC);
               server.secondaries.push_back(clientSoket);
	       releaseSem(SEM_SEC);
      	      
                


}
void threadEntry_(void *ptr)
{

		bool is_sec=false;//is the client a secondary server?

                PARA* para=(PARA *)ptr;
                ptr=NULL;

                int clientSoket=para->clientSoket;
                int numr=0;
		int numn=0;
		int byteRcved=0;
		

                pthread_t tid=para->thread;
                char *buffer=(char *)malloc(MAX_BUFFER_TO_HOLD*sizeof(char));
                char *mbuffer=(char *)malloc(MAX_BUFFER*sizeof(char));

                memset((void *)buffer, 0, MAX_BUFFER_TO_HOLD);
                memset((void *)mbuffer, 0, MAX_BUFFER);

                pthread_detach(tid);

		int timeout;
		server.type==PRIMARY? timeout=TIMEOUT : timeout=TIMEOUT_SEC;
                struct timeval tv={timeout,0L};
                fd_set fds;
                FD_ZERO(&fds);
                FD_SET(clientSoket, &fds);
		int numofslashn=0;
		server.type==PRIMARY? numofslashn=3:numofslashn=1;
		bool whilecondition;
		server.type==PRIMARY? whilecondition=(select(clientSoket+1, &fds, 0, 0, &tv)>0&&recv(clientSoket, mbuffer,MAX_BUFFER-1,0)>0&&continue_) \
				      : whilecondition=(recv(clientSoket, mbuffer,MAX_BUFFER-1,0)>0&&continue_) ;
                while(whilecondition)
                {
					
					tv.tv_sec=timeout;
					tv.tv_usec=0;
				    	FD_ZERO(&fds);
				    	FD_SET(clientSoket, &fds);



					byteRcved++;
					


					if(byteRcved>=MAX_BUFFER_TO_HOLD)
					{cout<<"Buffer size exceed MAX=1024"<<endl;
					break;}

					if(mystrcmp(mbuffer,"\r"))
					{        numr=numr+1;
							strcpy(mbuffer," ");



					}
					else if(mystrcmp(mbuffer,"\n"))
					{        numn=numn+1;
							strcpy(mbuffer," ");
					}


					strcat(buffer, mbuffer);

					if(mystrcmp(buffer,"-replica"))
					{//this client is a secondary server
						cout<<byteRcved<<endl;
						is_sec=true;
						cout<<"secondary server detected"<<endl;
						break;

					}

					if((numr)>=numofslashn||(numn)>=numofslashn)
					{
							if(server.type==SECONDARY)
								cout<<"secondary recieved "<<buffer<<endl;

							char *response=server.Response(buffer);
							
							if(server.type==PRIMARY)
								send(clientSoket,(void *)response, strlen(response),0);
							//*cont=2;
							if(response!=NULL)
								free(response);
						    response=NULL;

			                memset((void *)buffer, 0, MAX_BUFFER_TO_HOLD);
			                memset((void *)mbuffer, 0, MAX_BUFFER);
							numr=0;
							numn=0;
							byteRcved=0;

					}



					memset((void *)mbuffer, 0, MAX_BUFFER);

					server.type==PRIMARY? whilecondition=(select(clientSoket+1, &fds, 0, 0, &tv)>0&&recv(clientSoket, mbuffer,MAX_BUFFER-1,0)>0&&continue_) \
				      			: whilecondition=(recv(clientSoket, mbuffer,MAX_BUFFER-1,0)>0&&continue_) ;

                }




               // memset(cont,0,1);
                memset((void *)mbuffer, 0, MAX_BUFFER);
                memset((void *)buffer, 0, MAX_BUFFER_TO_HOLD);
                
		if(!is_sec&&server.type==PRIMARY)
			cout<<"client exited"<<endl;

                if(buffer!=NULL)
                {        free(buffer);
                        buffer=NULL;
                }
                if(mbuffer!=NULL)
                {       free(mbuffer);
                        mbuffer=NULL;
                }

		if(!is_sec)
                	close (clientSoket);


		
		if(is_sec)
			secondary((void *)para);

		free(para);
		para=NULL;
		if(server.type==PRIMARY)
                	pthread_exit(NULL);

}

void *threadEntry(void *ptr)
{
        threadEntry_(ptr);


}

void terminatesighandler(int sig)
{	  
	  if(sig==SIGPIPE)
		return ;
	  
	  removeAllSem();
	if(listenerT)
        pthread_cancel(listenerT);
	if(listenerSecT)
	pthread_cancel(listenerSecT);
	  is_crash=true;
	  continue_=false;

}

void *listenerEntry(void *ptr)
{

        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, (int*)0);
        pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS,(int*)0);
       // cout<< "Signal " << sig << " caught..." << endl;

        numT=0;//initially,it contains a thread for detecting user EOF on server side
        int connectionFd;
        struct sockaddr_in servaddr;
        char timebuffer[MAX_BUFFER+1];
        time_t currentTime;

        serverFd=socket(AF_INET,SOCK_STREAM,0);
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family=AF_INET;
        servaddr.sin_addr.s_addr=inet_addr(PRI_IP);
        servaddr.sin_port=htons(PRI_PORT);

        bind(serverFd, (struct sockaddr *)&servaddr, sizeof(servaddr));

        listen(serverFd, 100);


        while(continue_){

                //struct sockaddr Caddr;sighandler
                connectionFd=accept(serverFd,(struct sockaddr*)NULL, NULL);

                //cout<<Caddr;
                numT++;

                PARA *para=(PARA*)malloc(sizeof(PARA));
                para->index=numT-1;
                para->clientSoket=connectionFd;


                pthread_create(&para->thread,NULL,threadEntry,(void *)para);


                cout<<"client "<<numT<<" connected"<<endl;




        }

        pthread_exit(NULL);

}

void renewmasterbackup()
{
	ofstream bckup;
	bckup.open("backup/mstbackup.txt");
	bckup<<server.backup;
	bckup<<flush;
	bckup.close();
}

void *listenerSecEntry(void *ptr)
{	//here is the socket listener of the secondary server. here we just treate "server" as primary.

        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, (int*)0);
        pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS,(int*)0);
       // cout<< "Signal " << sig << " caught..." << endl;



	//char *hellostr=(char *)malloc(sizeof(char)*10);
	//strcpy(hellostr,"-replica");
        numT=0;//initially,it contains a thread for detecting user EOF on server side
        int connectionFd;
        struct sockaddr_in servaddr,secaddr;
        char timebuffer[MAX_BUFFER+1];
        time_t currentTime;
	
        serverFd=socket(AF_INET,SOCK_STREAM,0);
	/*memset(&servaddr, 0, sizeof(servaddr));
        secaddr.sin_family=AF_INET;
        secaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
        secaddr.sin_port=htons(22222);
	bind(serverFd, (struct sockaddr *)&secaddr, sizeof(secaddr));
*/
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family=AF_INET;
        servaddr.sin_addr.s_addr=inet_addr(PRI_IP);
        servaddr.sin_port=htons(PRI_PORT);

        if(connect(serverFd, (struct sockaddr *)&servaddr, sizeof(servaddr))<0)
	{
		cout<<"failed to connect to primary server. did you open primary server yet?\n";
		return NULL;
	}
	int tmp;
	if(tmp=send(serverFd,(void *)"-replica", 8,MSG_NOSIGNAL)!=8)
	{
		
		cout<<"failed to send -replica to primary"<<endl;
		return NULL;
	}

 	
        char *mbuffer=(char *)malloc(MAX_BUFFER*sizeof(char));
	memset(mbuffer,0,MAX_BUFFER);
	int num_end=0;
	cout<<"Requesting privious primary server's log with content:\n-----------"<<endl;
	ofstream f(server.backup.c_str());
	while(recv(serverFd, mbuffer,MAX_BUFFER-1,0)>0)
	{	//end of sent log is "&&&&&&&&&&"
		
		if(mystrcmp(mbuffer,"&"))
			num_end++;
		else
		{
			cout<<mbuffer;
			f<<mbuffer;f<<flush;
			memset(mbuffer,0,strlen(mbuffer));
		}
		if(num_end==10)
			break;


	}
	cout<<"\n----------\nLog recieved in its entirety"<<endl<<endl;
	f.close();

	
	server.Rollback();
	
	
	free(mbuffer);
	mbuffer=NULL;
	cout<<"Recover finished, this secondary server has been activated"<<endl;
	 PARA *para=(PARA*)malloc(sizeof(PARA));
	 para->index=numT-1;
	 para->clientSoket=serverFd;
	 threadEntry_((void *)para);
	 cout<<"primary server stopped. Secondary server is now Primary server"<<endl;
	 renewmasterbackup();
	 semenable=true;
	 createSem();
	 memset(PRI_IP, 0, strlen(PRI_IP));
	 memcpy(PRI_IP, SERVER_IP, strlen(SERVER_IP));
	 PRI_PORT=SERVER_PORT;
	 
	 ofstream ofs(primarytxt);
	 ofs<<PRI_IP<<" "<<PRI_PORT;
	 ofs<<flush;
	 ofs.close();
	 server.type=PRIMARY;
	 listenerEntry((void *)NULL);

	close(serverFd);	
        pthread_exit(NULL);
	

}



bool inputAvailable()  
{
  struct timeval tv={0L,0L};
  fd_set fds;
  FD_ZERO(&fds);
  FD_SET(0, &fds);
  return select(1, &fds, NULL, NULL, &tv);
}

void makebackup()
{	struct stat st;
 	ofstream bckup;
	if(server.type==SECONDARY || (server.type==PRIMARY &&stat("backup/mstbackup.txt",&st)!=0))
	{	//master backup file not exist. create rand log,and cread master backup to record log's name
		char *id;
		do
		{	
			id=guid();
		}
		while(stat(id,&st)==0);

		server.backup="";
		server.backup.assign(id);

		bckup.open(id,ios::app);
		bckup.close();
		cout<<id<<server.backup;
		
      	}
	if(server.type==PRIMARY &&stat("backup/mstbackup.txt",&st)!=0)
	{	
		bckup.open("backup/mstbackup.txt");
		bckup<<server.backup<<endl;
		bckup<<flush;
		bckup.close();
	}
	else if(server.type==PRIMARY &&stat("backup/mstbackup.txt",&st)==0)
	{

		FILE *fp = fopen("backup/mstbackup.txt", "r");
		char str[100];
		memset(str,0,100);
		if(fgets(str,sizeof(str),fp) != NULL)
		{
			string tmp(str);
			if(tmp[tmp.size()-1]=='\n'||tmp[tmp.size()-1]=='\r')
			tmp.erase(tmp.size()-1);
		
			server.backup="";
			server.backup.assign(tmp);
		
			bckup.open(server.backup.c_str(),ios::app);
			bckup.close();
		}






	}
}


int main(int argc, char* argv[])
{
	
cout<<endl<<endl;
	rollback=false;
	maxsem=START_SEM;
	is_crash=false;
	signal(SIGPIPE, &terminatesighandler);
	signal(SIGTSTP, &terminatesighandler);
	signal(SIGSTOP, &terminatesighandler);
	signal(SIGABRT, &terminatesighandler);
	signal(SIGTERM, &terminatesighandler);
	signal(SIGINT, &terminatesighandler);
	char *localhost=(char *)"127.0.0.1";

	if(argc!=6||(memcmp(argv[1],"p",strlen(argv[1]))!=0&&memcmp(argv[1],"s",strlen(argv[1]))!=0))
	{
		
		cout<<"invalid parameter sets"<<endl;
		cout<<"argument for primary server: p [primary.txt location] [ip_addr] [port] [userdir]"<<endl;
		cout<<"argument for secondary server: s [primary.txt location] [ip_addr] [port] [userdir]"<<endl;

		return 1;
	}
	struct stat st;


	 if(stat("backup",&st)!=0)
	    	 mkdir("backup",0777);

	memcmp(argv[1],"p",strlen(argv[1]))?server.type=SECONDARY : server.type=PRIMARY;
	
      	 makebackup();
	
	//read primary.txt
	
  	
	primarytxt=argv[2];

	if(server.type==PRIMARY)
	{
		ofstream ofs(primarytxt);
		ofs<<argv[3]<<" "<<argv[4];

	}
	ifstream fin(primarytxt);
	if(!(fin>>PRI_IP>>PRI_PORT))
	{
		cout<<"invalid primary txt file content. \nplease specify ip and port of primary server"<<endl;
		return 1;
	}
	if(!memcmp(PRI_IP,"localhost",strlen(PRI_IP))) 
	{	
		memset(PRI_IP, 0, MAX_IP_LEN);
		strcpy(PRI_IP,(char *)"127.0.0.1");

	}
	fin.close();
	
        if(server.type==PRIMARY)
	{server.Recover();}

	memcmp(argv[3],"localhost",strlen(argv[3]))? SERVER_IP=argv[3] :  SERVER_IP=(char *)"127.0.0.1" ;

 	SERVER_PORT=atoi(argv[4]);


	
       	
        server.setdir(argv[5]);
	
	cout<<"**************************************"<<endl;
	cout<<"press Enter to exit"<<endl<<endl;
	cout<<"Note: each connection timeout="<<TIMEOUT<<" seconds"<<endl<<"if no request from this client sent to server"<<endl;
	cout<<"**************************************"<<endl;
	if(server.type==PRIMARY)  	
	{	
		cout<<endl<<endl<<"Primary Server starts to listen connections........"<<endl<<endl;
	}
	else
	{
		cout<<endl<<endl<<"Secondary server starts........"<<endl<<endl;
	}
        server.type==PRIMARY? pthread_create(&listenerT,NULL,listenerEntry,(void *)NULL):pthread_create(&listenerSecT,NULL,listenerSecEntry,(void *)NULL);
        continue_=true;

	server.type==PRIMARY?semenable=true : semenable=false;
	createSem();



        while(!inputAvailable())
        {
        }
	if(!is_crash)
		removeAllSem();
        continue_=false;
	if(listenerT)
        pthread_cancel(listenerT);
	if(listenerSecT)
	pthread_cancel(listenerSecT);




        cout<<"server ended"<<endl;
        close (serverFd);
        if(!is_crash)
        	server.destroy();
        else
        	server.destroy_();
	
        return 0;
}
/*



*/
