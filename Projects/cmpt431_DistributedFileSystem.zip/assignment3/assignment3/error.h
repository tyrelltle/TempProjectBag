#ifndef ERROR_H
#define ERROR_H

enum ERROR
{
	INVTRANS 	=201,
	INVOP		=202,
	INVMSG		=204,
	INVIO		=205,
	INVFILE		=206

};





#endif
