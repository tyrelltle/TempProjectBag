#ifndef FILELOCK_H
#define FILELOCK_H
#include <map>
#include "Helper.h"
#include <errno.h>
//#include <string>
#define SEM_SIZE 3
#define START_SEM 4

using namespace std;
class FileLock
{
public:
	FileLock()
	{

	};

	

	~FileLock()
	{
				
		

	};

	void isnewFIle(string fname)
	{
		int i;
		if(semenable)
			getSem(SEM_SIZE);

		if(locks.find(fname)==locks.end())
		{
			i=locks.size()+START_SEM;
			locks[fname]=i;
			maxsem=i;
			int semid;
			if(semenable)
			{
				semid=semget(i,1,0666|IPC_CREAT);
				if(semid<0)
				{
					cout<<"failed to create sem: "<<i<<",err: "<<strerror(errno)<<endl;
					

				}
				semctl( semid, 0, SETVAL, 1 );
			}


		}
		if(semenable)
			releaseSem(SEM_SIZE);

	};

	void lockFile(string fname)
	{
		
		getSem(locks[fname]);
	

	}

	void releaseFile(string fname)
	{
		releaseSem(locks[fname]);

	}

private:

	map<string, int > locks;





};
#endif


