#ifndef HELPER_H
#define HELPER_H
#include <unistd.h>
#include <time.h>
#include <stdlib.h>
#include <sys/sem.h>
#include <vector>
#include <errno.h>
#include "MessageContext.h"
using namespace std;
 
int maxsem;  
bool semenable;    
bool rollback;
	
    void createSem()
    {
	if(!semenable)
		return ;
	int semid;
	//cout<<"num of semaphors to be created:"<<maxsem<<endl;
	for(int i=1;i<=maxsem;i++)
	{
		
		
		semid=semget(i,1,0666|IPC_CREAT);

			
				
		semctl( semid, 0, SETVAL, 1 );
	

	}
    }

	
    inline int Digits(const int number){
    	int digits = 0;
    	int step = 1;
    	while (step <= number)
    	{		digits++;		step *= 10;	
	}
    	return digits ? digits : 1;
    }




	int getSem(int semID)
	{

		struct sembuf sb;
		int semid;
		
		if(semenable)
		{	semid=semget(semID, 1,0);

			sb.sem_num=0;
			sb.sem_op=-1;
			sb.sem_flg=0;
			semop(semid,&sb,1);
		}

	}

	int releaseSem(int semID)
	{

		struct sembuf sb;
		int semid;
		if(semenable)
		{
			semid=semget(semID, 1,0);


			sb.sem_num=0;
			sb.sem_op=1;
			sb.sem_flg=0;
			semop(semid,&sb,1);
		}

	};








	bool record(REQUEST *rqt, vector<int> &secs, int SEM_SEC, string backup)
	{
		
		ifstream ifs(backup.c_str());
		if(!ifs.is_open())
		{
			cout<<"backup file can not be opened"<<endl;
			return false;
		}
		ofstream f(backup.c_str(),ios::app);
		int size=sizeof(REQUEST)+
				 sizeof(char)*rqt->method.size()+
				 Digits(rqt->tranID)*sizeof(char)+
				 sizeof(char)*Digits(rqt->msg_sqc)+
				 sizeof(char)*Digits(rqt->ctn_len)+
				 sizeof(char)*rqt->data.size();

		char *buf=(char *)malloc(size);
		memset(buf,0,size);
	
		sprintf(buf,"%s %d %d %d    %s\n",rqt->method.c_str(),rqt->tranID,rqt->msg_sqc,rqt->ctn_len,rqt->data.c_str());
		
		f<<buf;
		f<<flush;
		f.close();
		
		getSem(SEM_SEC);
		
		for(int i=0;i<secs.size();i++)
		{
			cout<<"sending to replica "<<buf<<endl;
			if(send(secs[i],(void *)buf, strlen(buf),MSG_NOSIGNAL)!=strlen(buf))
			{	secs[i]=-1;
				cout<<"replica disconnected"<<endl;
			}

		}
		vector<int>::iterator it;
		for(it=secs.begin();it<secs.end();it++)
			if(*it==-1)
				it=secs.erase(it);
		
		releaseSem(SEM_SEC);

		if(buf)
			free(buf);
		buf=NULL;

		return true;

	};



	bool unrecord(string backup)
	{

		remove(backup.c_str());
		
		/*ifstream ifs(backup.c_str());
		if(!ifs.is_open())
		{
			cout<<"backup file can not be opened"<<endl;
			return false;
		}
		ofstream f(backup.c_str());
		f<<"";
		f<<flush;
		f.close();*/
		return true;

	};


	
	void removeSem(int semID)
	{
		int semid;

		if(semenable)
		{
			semid=semget(semID,1,0);
			semctl(semid,0,IPC_RMID);
		}


	};

	void removeAllSem()
	{
		if(!semenable)
			return ;
		//cout<<"num of semaphors to be Removed:"<<maxsem<<endl;
		for(int i=1;i<=maxsem;i++)
		{


			removeSem(i);
		}
	}

	char* readfile(string nm, long &len)
	{

		FILE *fp;
		char *buf;

		fp=fopen(nm.c_str(),"r");
		if(fp==NULL)
			return NULL;
		fseek(fp,0,SEEK_END); //go to end
		len=ftell(fp); //get position at end (length)

		fseek(fp,0,SEEK_SET); //go to beg.
		if(len<=0)
		{	
			char *ret=(char *)malloc(sizeof(char)*5);
			strcpy(ret,"empty");
			return ret;

		}
		buf=(char *)malloc(len); //malloc buffer
		fread(buf,1,len,fp);  //read into buffer
		fclose(fp);

		return buf;

	};

	char* readfile_sec(string nm, long &len)
	{

		FILE *fp;
		char *buf;

		fp=fopen(nm.c_str(),"r");
		if(fp==NULL)
			return NULL;
		fseek(fp,0,SEEK_END); //go to end
		len=ftell(fp); //get position at end (length)

		fseek(fp,0,SEEK_SET); //go to beg.

		if(len<=0)
		{	
			char *ret=(char *)malloc(sizeof(char)*12);
			strcpy(ret,"&&&&&&&&&&");
			return ret;

		}
		
		buf=(char *)malloc(len+12); //malloc buffer
		fread(buf,1,len,fp); //read into buffer
		fclose(fp);

		return buf;

	};


	string remove_if(string inp, char tar)
	{
	    string ret="";
	    for(int i=0;i<inp.size();i++)
	    	if(inp[i]!=tar)
	    		ret.push_back(inp[i]);

	    return ret;
	}

	string remove_if2(string inp, char tar)
	{
	    string ret="";
	    for(int i=0;i<inp.size();i++)
	    	if(inp[i]!=tar)
	    		ret.push_back(inp[i]);
		else
			ret.push_back('_');

	    return ret;
	}
/*
	void split(vector<string> &dest,char sourse[], int sourseSz,char what)
	{
		dest.empty();
		dest.push_back("");
		bool was=false;
		int numspace=0;
		for(int i=0;i<sourseSz;i++)
		{
			if(sourse[i]!=what||(numspace>=7))
			{
				if(was)
				{
					dest.push_back("");


				}
				(dest[dest.size()-1]).push_back( sourse[i]);
				was=false;
			}
			else if(numspace<7)
			{
				was=true;
				numspace++;
			}
		}


	};
	*/
	void split(vector<string> &dest,char sourse[], int sourseSz,char what)
	{
		dest.empty();
		dest.push_back("");
		bool was=false;
		int numspace=0;
		for(int i=0;i<sourseSz;i++)
		{
			if(sourse[i]!=what||(numspace>4))
			{
				if(was)
				{
					dest.push_back("");


				}
				(dest[dest.size()-1]).push_back( sourse[i]);
				was=false;
			}
			else if(numspace<=4)
			{
				was=true;
				numspace++;
			}
		}

		numspace=0;//here we use it as counter

		if(dest.size()>0)
		{
			string tmp=dest[dest.size()-1];
			while(tmp[numspace]==what)
			{numspace++;}

			if(numspace>0)
			tmp.erase(0,numspace);
			dest[dest.size()-1]=tmp;
		}

	};

	struct REQUEST* parse(char buf[], int sz)
	{

		vector<string> strs;
		split(strs, buf,sz, ' ');
		struct REQUEST *a=new struct REQUEST;

		a->method=strs[0];

		1<strs.size()?a->tranID=atoi(strs[1].c_str()):a->tranID=0;

		2<strs.size()?a->msg_sqc=atoi(strs[2].c_str()):a->msg_sqc=0;

		3<strs.size()?a->ctn_len=atoi(strs[3].c_str()):a->ctn_len=0;
		4<strs.size()?a->data=strs[4].c_str():a->data="";


		return a;
	};


	char *guid()
	{
		time_t result;
    		result = time(NULL);
   		string a;
		a.assign(asctime(localtime(&result)));
		string ret=remove_if2(a, ' ');
		if(ret[ret.size()-1]=='\n')
			ret.erase(ret.size()-1);
		
		ret.insert(0,"backup/");
		return (char *)ret.c_str();//return (char *)ret.c_str();
	}
#endif
