#ifndef MESSAGE_H
#define MESSAGE_H
#include <stdlib.h>
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

enum MESSAGE_TYPE
{
	REQUEST_MSG,
	RESPONSE_MSG
	
};

enum MESSAGE_METHOD
{
	WRITE,
	READ,
	NEW_TXN,
	COMMIT,
	ABORT,
	ACK,
	ASK_RESEND,
	ERROR
};

struct REQUEST
{

	string method;
	int tranID;//transaction id
	int msg_sqc;//message sequence number

	int ctn_len;//content length

	string data;
};

struct RESPONSE
{

	string method;
	int tranID;//transaction id
	int msg_sqc;//message sequence number
	int err;
	int ctn_len;//content length

	string reason;
};

typedef struct REQUEST Request;
typedef struct RESPONSE Response;

static const string Requests[]={"WRITE","READ","NEW_TXN","COMMIT","ABORT",
			       "ACK","ASK_RESEND","ERROR"};

inline int Digit(const int number){
   	int digits = 0;
   	int step = 1;
   	while (step <= number)
   	{		digits++;		step *= 10;	}
   	return digits ? digits : 1;
}


inline int sizeof_(struct RESPONSE *rqt)
{
	return sizeof(RESPONSE)+sizeof(char)*(Digit(rqt->ctn_len)+
										   Digit(rqt->err)+
										   Digit(rqt->msg_sqc)+
										   Digit(rqt->tranID)+
										   rqt->reason.length()+
										   rqt->method.length());

}
inline char * toResponse(struct RESPONSE *rqt)
{

	int sz=sizeof_(rqt);
    char *ret=(char*)malloc(sz);

	memset(ret,0,sz);

	if(rqt->ctn_len==0)
		sprintf(ret, "%s %d %d %d %d \r\n\r\n\r\n", rqt->method.c_str(), rqt->tranID, rqt->msg_sqc,rqt->err,rqt->ctn_len);
	else
		sprintf(ret, "%s %d %d %d %d \r\n\r\n%s\r\n", rqt->method.c_str(), rqt->tranID, rqt->msg_sqc,rqt->err,rqt->ctn_len,rqt->reason.c_str());


	return ret;

}

inline char* toResponseERR(int err,int tranid,string reason)
{
	char* ret;

	RESPONSE *rsp=new RESPONSE;

	rsp->method=Requests[ERROR];
	rsp->err=err;
	rsp->ctn_len=reason.size();
	rsp->msg_sqc=0;
	rsp->reason=reason;
	rsp->tranID=tranid;
	ret=toResponse(rsp);
	delete(rsp);
	rsp=NULL;
	return ret;
}
#endif
