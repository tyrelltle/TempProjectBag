#ifndef SERVER_H
#define SERVER_H

#include "MessageContext.h"
#include <sstream>
#include <vector>
#include <string>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <exception>
#include <fstream>
#include <map>
#include <sys/sem.h>
#include "Helper.h"
#include "FileLock.h"
#include "error.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <algorithm>
#define SEM_TRANS	1
#define SEM_SEC		2
#define MAX_FILE_DIR	128
bool recover;


enum SERVER_TYPE
{
	PRIMARY,
	SECONDARY
	
};


class Transaction
{
public:
	int id;
	string filenm;
	bool commited;
	map<int,REQUEST*> *requests;

	Transaction(string fn,int id)
	{

		requests=new map<int,REQUEST*>();
		filenm=fn;
		this->id=id;
		this->commited=false;
	};

	int addRequest(REQUEST *r)
	{
		if(r->msg_sqc<1)
			return false;
		if(requests->find(r->msg_sqc)!=requests->end())
			delete((*requests)[r->msg_sqc]);
		(*requests)[r->msg_sqc]=r;
		return true;//r->msg_sqc;

	}

	char * commit(FileLock &filelock, REQUEST *rqt_commit,char *dir, vector<int> &secs,string backup)
	{
		struct stat st;
		string fnm(filenm);
		REQUEST *rqt;
		RESPONSE *rsp;
		char * ret;
		int mmsg=rqt_commit->msg_sqc;

		if(this->commited)
			return NULL;

if(!recover)
		if(mmsg<requests->size())
		{
			stringstream *ss =new stringstream(stringstream::in | stringstream::out);
			(*ss)<<"provided total message number is too small.";
			ret=toResponseERR(INVOP,id,ss->str());
			delete(ss);
			return ret;

		}


		

		ofstream fout;
	     fnm.insert(0,dir);

	     filelock.lockFile(fnm);

if(!recover||rollback)
{

	
	     string outbuffer="";


	     if(!fout.good())
	     {
			stringstream *ss =new stringstream(stringstream::in | stringstream::out);
			(*ss)<<"file '"<<fnm<<"' access error:"<<strerror(errno);
			ret=toResponseERR(INVIO,id,ss->str());
			delete(ss);
			return ret;

	      }
		for(int i=1;i<=mmsg;i++)

		{
			if(requests->find(i)==requests->end())
			{
				filelock.releaseFile(fnm);

				RESPONSE *rsp=new RESPONSE;
				rsp->method=Requests[ASK_RESEND];
				rsp->err=0;
				rsp->ctn_len=0;

				rsp->msg_sqc=i;
				rsp->reason="";
				rsp->tranID=id;
				ret= toResponse(rsp);
				delete(rsp);
				return ret;

			}

			else
			{
				rqt=(*requests)[i];
				if(rqt->method==Requests[WRITE])
				{
					outbuffer.append(rqt->data);
					outbuffer.append("\n");
						
					

					//delete(rqt);
					//requests->erase(requests->begin()+i);
				}
			}
		}

		if(stat(dir,&st)!=0)
			mkdir(dir,0777);
	     

	    
	     	fout.open(fnm.c_str(),ios::app);
		fout<<outbuffer;
		fout<<flush;
if(!recover)
		record(rqt_commit,secs,SEM_SEC,backup);
}//end if not recover
		this->commited=true;
if(!recover||rollback)
		fout.close();

if(!recover)
		filelock.releaseFile(fnm);

		return NULL;
	}

	~Transaction()
	{
		for(map<int,REQUEST*>::iterator i=requests->begin();i!=requests->end();i++)
		{

			delete(i->second);
			i->second=NULL;
		}


		delete(requests);

	};
};













class Server
{
public:
	Server(){

		//strcpy(filedir,"userfile/");

		
		cur_uuid=0;
		recover=false;
		
	};


	void setdir(char *fdir)
	{
		
		sprintf(this->filedir,"%s/",fdir);

	}
	void destroy()
	{
		map<long int,Transaction *>::iterator p;
		for(p=transactions.begin();p!=transactions.end();p++)
		{
			delete(p->second);

		}
		if(semenable)
			getSem(SEM_SEC);

		for(int i=0;i<secondaries.size();i++)
		{
			close(secondaries[i]);
		}	
		if(semenable)
			releaseSem(SEM_SEC);

		
		secondaries.clear();
		unrecord(backup);
		if(type==PRIMARY)
			remove("backup/mstbackup.txt");
	}

	void destroy_()
	{
		map<long int,Transaction *>::iterator p;
		for(p=transactions.begin();p!=transactions.end();p++)
		{
			delete(p->second);

		}

		if(semenable)
			getSem(SEM_SEC);
		for(int i=0;i<secondaries.size();i++)
		{
			close(secondaries[i]);
		}
		if(semenable)	
			releaseSem(SEM_SEC);

		secondaries.clear();
		//unrecord();
	}


	char *Response(char *rqt)
	{


		RESPONSE response;
		char* ret;
		long len=0;
		int msg_sqc=0;
		REQUEST *request=parse(rqt, strlen(rqt));
		char end=request->data[request->data.size()-1];
		if(end=='\n' ||end=='\r'||end==' ')
			request->data.erase(request->data.size()-1);


		if(!recover&&request->method==Requests[READ])
		{

			string data=request->data;
			data=remove_if(data,' ');

			if(data=="")
			{



				ret=toResponseERR(INVOP,request->tranID,"please enter name of file to be read");


			}
			else
			{
				data.insert(0,this->filedir);
				request->data=data;

				ret=readfile(data, len);

				if(ret==NULL)
				{
					ret=toResponseERR(INVIO,request->tranID,"file not found");



				}
			}


		}
		else if(request->method==Requests[NEW_TXN])
		{
			string data=request->data;
			data=remove_if(data,' ');


			if(data==""||data.size()==0||(data.find(" ")!=string::npos))

			{

if(!recover)
				ret=toResponseERR(INVOP,request->tranID,"please enter filename in data field");


			}

			else
			{
				

				
				request->data=data;
				if(rollback)
				{	
					
					string tmp(request->data);
					tmp.insert(0,this->filedir);
					if(std::find(refreshedfiles.begin(),refreshedfiles.end(),tmp)==refreshedfiles.end())
					/*ofstream f(tmp.c_str());
					f<<"";
					f<<flush;
					f.close();*/
					{	remove(tmp.c_str());
						refreshedfiles.push_back(tmp);
					}
						
				}
if(!recover)
				getSem(SEM_TRANS);

				int uid=cur_uuid++;
if(!recover)
				releaseSem(SEM_TRANS);

				string tmp=data;
				tmp.insert(0,this->filedir);
				this->filelock.isnewFIle(tmp);
if(!recover)			
				record(request,secondaries,SEM_SEC,backup);

				transactions[uid]=new Transaction(data,uid);
				//transactions[uid]->addRequest(request);

if(!recover)
{				RESPONSE *rsp=new RESPONSE;
				rsp->method=Requests[ACK];
				rsp->err=0;
				rsp->ctn_len=0;

				rsp->msg_sqc=0;
				rsp->reason="";
				rsp->tranID=uid;
				ret= toResponse(rsp);
				delete(rsp);
				rsp=NULL;
}
			}


		}
		else if(request->method==Requests[WRITE])
		{
			string data=request->data;
			data=remove_if(data,' ');
			if(request->data=="")
			{
if(!recover)
				ret=toResponseERR(INVOP,request->tranID,"please fill data field");

			}
			else if(transactions.find(request->tranID)==transactions.end())
			{
if(!recover)
				ret=toResponseERR(INVTRANS,request->tranID,"transaction not exist");

			}
			else if(transactions[request->tranID]->commited)
			{
if(!recover)
				ret=toResponseERR(INVOP,request->tranID,"transaction alread committed");

			}
			else
			{



				if(!transactions[request->tranID]->addRequest(request)){
if(!recover)
					ret=toResponseERR(INVOP,request->tranID,"new msg_sqc should >=1");

				}
				else
				{
if(!recover)
{
					record(request,secondaries,SEM_SEC,backup);

					RESPONSE *rsp=new RESPONSE;
					rsp->method=Requests[ACK];
					rsp->err=0;
					rsp->ctn_len=0;
					rsp->msg_sqc=request->msg_sqc;
					rsp->reason="";
					rsp->tranID=request->tranID;
					ret= toResponse(rsp);
					delete(rsp);
					rsp=NULL;
}
				}

			}

			//initializer
		}
		else if(request->method==Requests[COMMIT])
		{

				if(transactions.find(request->tranID)==transactions.end())
				{
if(!recover)
					ret=toResponseERR(INVTRANS,request->tranID,"transaction not exist");

				}
				else if(request->msg_sqc<0)
				{
if(!recover)
					ret=toResponseERR(INVOP,request->tranID,"msg_sqc field can not less than zero");


				}
				else
				{


					
					ret=transactions[request->tranID]->commit(this->filelock,request,filedir,secondaries,backup);

if(!recover)
					if(ret==NULL)
					{

						RESPONSE *rsp=new RESPONSE;
						rsp->method=Requests[ACK];
						rsp->err=0;
						rsp->ctn_len=0;
						rsp->msg_sqc=msg_sqc;
						rsp->reason="";
						rsp->tranID=request->tranID;
						ret= toResponse(rsp);
						delete(rsp);
						rsp=NULL;
					}
				}


		}
		else if(request->method==Requests[ABORT])
			{

			    map<long int,Transaction *>::iterator it=transactions.find(request->tranID);
				if(it==transactions.end())
				{

if(!recover)
					ret=toResponseERR(INVTRANS,request->tranID,"transaction not exist");


				}
				else if(transactions[request->tranID]->commited)
				{
if(!recover)
					ret=toResponseERR(INVOP,request->tranID,"transaction alread committed");

				}
				else
				{

if(!recover)
					record(request,secondaries,SEM_SEC,backup);
					delete(it->second);
					it->second=NULL;
					transactions.erase(it);




if(!recover)
{
					RESPONSE *rsp=new RESPONSE;
					rsp->method=Requests[ACK];
					rsp->err=0;
					rsp->ctn_len=0;
					rsp->msg_sqc=0;
					rsp->reason="";
					rsp->tranID=request->tranID;
					ret= toResponse(rsp);
					delete(rsp);
					rsp=NULL;
}


				}


		}
		else
		{

if(!recover)
			ret=toResponseERR(INVMSG,request->tranID,"Wrong message format");


		}
		//delete request;
if(!recover)
		return ret;
else
		return NULL;
	};




	void Recover()
	{
		recover=true;
		ifstream ifs(backup.c_str());
		cout<<"Server is in process of recovery......."<<endl;
		FILE *fp;
		char str[100];
		fp = fopen(backup.c_str(), "r");
		if(!fp)
		{
		  cout<<"Failed to load backup file"<<endl;
		  return ; // bail out if file not found
		}


		while(fgets(str,sizeof(str),fp) != NULL)
		{
			this->Response(str);
			memset(str,0,100);
		}


		recover=false;

		cout<<"Recover finished......."<<endl;

	}
	void Rollback()
	{	//re-build the trans files
		rollback=true;
		refreshedfiles.clear();
		Recover();
		refreshedfiles.clear();
		rollback=false;

	}

	int type;
	vector<int> secondaries;
	string backup;
private:
	
	
	vector<string> refreshedfiles;//when replica rolling back, it has to delete old existing trans files. this vector remembers which are deleted 
	map<long int,Transaction *> transactions;
	
	FileLock filelock;
	long int cur_uuid;
	char filedir[MAX_FILE_DIR];
	

};

#endif
